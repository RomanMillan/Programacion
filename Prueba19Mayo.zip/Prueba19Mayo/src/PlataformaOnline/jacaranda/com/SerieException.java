package PlataformaOnline.jacaranda.com;

public class SerieException extends Exception {

	
	private static final long serialVersionUID = 1L;

	public SerieException(String msg) {
		super(msg);
	}
}
