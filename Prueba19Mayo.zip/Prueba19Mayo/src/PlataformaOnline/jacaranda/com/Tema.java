package PlataformaOnline.jacaranda.com;

public enum Tema {
	DRAMA, COMEDIA,INTRIGA, CIENCIAFICCION
}
